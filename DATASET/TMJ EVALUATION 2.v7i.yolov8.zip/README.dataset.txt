# TMJ EVALUATION 2 > 2024-07-12 2:29pm
https://universe.roboflow.com/rocky-vu4zh/tmj-evaluation-2

Provided by a Roboflow user
License: CC BY 4.0

